# Beauty Agenda — Android + Firebase + GitHub Actions

Projeto Flutter para Android, visual preto, branco e lilás. Recursos no código: login/criação de conta por e-mail, cadastro de cliente, catálogo de serviços, pedidos de agendamento pela cliente, agenda administrativa, seção Instant com publicação de fotos/vídeos pelo administrador, atalho de WhatsApp com texto pré-preenchido e notificação local após agendamento administrativo.

## O que esta versão faz e o que ainda exige configuração
- As clientes criam uma conta, escolhem um serviço e enviam um **pedido de horário**. Ele não é confirmado automaticamente: a profissional deve revisar e mudar o status.
- A profissional pode manter serviços, clientes, agenda e publicações do Instant.
- Fotos/vídeos são guardados no Firebase Storage; os metadados ficam no Firestore.
- O atalho de WhatsApp abre uma conversa com texto pré-preenchido. Não envia mensagens automaticamente.
- A notificação local do exemplo é pontual no momento em que a profissional cria um agendamento. Lembretes automáticos com o app fechado exigem FCM + função agendada no backend, ainda não incluída.
- Ainda é necessário executar o build no GitHub Actions e instalar/testar o APK em um aparelho. Não há APK compilado dentro deste ZIP.

## 1. Criar o Firebase pelo celular
1. Abra https://console.firebase.google.com/ no Chrome e crie um projeto chamado `Beauty Agenda`.
2. Em **Authentication > Sign-in method**, habilite **Email/Password**.
3. Em **Firestore Database**, crie o banco de dados.
4. Em **Storage**, habilite o bucket para as fotos e os vídeos do Instant. Confira no console as condições de plano/cobrança exibidas para seu projeto.
5. Em Configurações do projeto > Seus apps, adicione um app **Android** com este ID exato: `com.beautyagenda.app`.
6. Baixe o arquivo `google-services.json` para o celular e abra-o como texto. Vamos colar seu conteúdo em um secret privado no GitHub; não coloque o arquivo no código público.

## 2. Criar um repositório privado
1. Entre em https://github.com/new.
2. Nome: `beauty-agenda`; marque **Private**; crie o repositório com README opcional.
3. Envie este arquivo ZIP para a raiz do repositório pelo botão **Add file > Upload files**. O ZIP pode ficar temporariamente na raiz; ele não contém suas credenciais Firebase.
4. Abra **Code > Codespaces > Create codespace on main** (se Codespaces estiver disponível na sua conta). No terminal web do Codespaces execute estes comandos, ajustando o nome do ZIP apenas se o navegador tiver renomeado o arquivo:
   ```bash
   unzip Beauty_Agenda_GitHub_CI.zip -d /tmp/beauty
   cp -a /tmp/beauty/beauty_agenda/. .
   rm Beauty_Agenda_GitHub_CI.zip
   git add .
   git commit -m "Prepare Beauty Agenda Android cloud build"
   git push
   ```
   Esses comandos colocam os arquivos do projeto na raiz do repositório e mantêm o workflow oculto `.github/workflows/build-apk.yml`. Codespaces pode ter limites de uso conforme o plano da conta.

## 3. Conectar o Firebase ao build
1. No repositório GitHub, abra **Settings > Secrets and variables > Actions > New repository secret**.
2. Nome do secret: `GOOGLE_SERVICES_JSON`.
3. Valor: cole o conteúdo completo do `google-services.json` baixado do Firebase. Salve. É um arquivo de configuração do app; regras seguras de Firestore/Storage continuam obrigatórias.
4. Não crie nem publique uma chave de service account e não use credenciais administrativas em aplicativo móvel.

Durante o build, um script valida se o JSON contém o app Android `com.beautyagenda.app` e gera `lib/firebase_options.dart`. Se o ID do app estiver diferente, o build vai falhar com uma mensagem explicativa.

## 4. Configurar as regras do Firebase
No Firebase Console, publique o conteúdo de `firestore.rules` em **Firestore Database > Rules** e `storage.rules` em **Storage > Rules**. Elas restringem publicação de Instant/serviços à conta com papel `admin`, permitem que usuários autenticados leiam o feed e que cada cliente crie pedidos ligados ao próprio UID.

## 5. Criar a conta da administradora
1. Depois de instalar o APK, crie uma conta com seu e-mail, nome, telefone e endereço.
2. No Firebase Console > Firestore Database > coleção `users`, abra o documento cujo ID é o UID da sua conta.
3. Altere o campo `role` de `client` para `admin` manualmente. Isso é proposital: o aplicativo não permite que alguém se torne administradora por conta própria.
4. Saia e entre novamente. A conta verá Agenda, Instant, Clientes e Serviços. Contas comuns verão Agendar e Instant.

## 6. Gerar e baixar o APK pelo Android
1. Abra a aba **Actions** do repositório. Habilite Actions se o GitHub pedir.
2. Selecione o workflow **Build Beauty Agenda APK** e toque em **Run workflow**.
3. Abra a execução. Aguarde ficar verde (**Success**). Se falhar, abra a execução e leia o passo em vermelho; causas comuns são secret Firebase ausente/JSON errado ou erro de compilação.
4. Na execução concluída, encontre **Artifacts** e baixe `beauty-agenda-apk`.
5. Extraia o ZIP do artefato. O arquivo final é `app-release.apk`. Toque nele no celular e permita a instalação pelo navegador/gerenciador de arquivos se o Android solicitar.

O artefato fica disponível por 14 dias, após o qual uma nova execução pode ser disparada.

## 7. Regras de segurança e uso real
Antes de divulgar o app às clientes, teste criação de conta, pedidos, alteração de status e publicação/exclusão de mídia. Configure aviso de privacidade e consentimento para fotos/vídeos, política de retenção e exclusão de dados conforme a LGPD. A implementação ainda precisa de prevenção de conflitos de horários, lembretes remotos e validação de mídia em servidor para um uso comercial mais robusto.
