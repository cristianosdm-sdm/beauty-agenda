import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

const lilac = Color(0xFFB79BEA);
const dark = Color(0xFF111114);
final notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  await notifications.initialize(const InitializationSettings(android: android));
  runApp(const BeautyAgendaApp());
}

class BeautyAgendaApp extends StatelessWidget {
  const BeautyAgendaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Beauty Agenda',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF7F6F9),
      colorScheme: ColorScheme.fromSeed(seedColor: lilac, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: dark, foregroundColor: Colors.white),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
      cardTheme: CardThemeData(color: Colors.white, elevation: 1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data == null ? const LoginPage() : const HomePage();
      },
    ),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(), password = TextEditingController();
  bool register = false, busy = false;
  String? error;
  final fullName = TextEditingController(), phone = TextEditingController(), address = TextEditingController();
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (register) {
        if (password.text.length < 6) throw FirebaseAuthException(code: 'weak-password', message: 'A senha deve ter pelo menos 6 caracteres.');
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
        await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({
          'email': email.text.trim(), 'name': fullName.text.trim(), 'phone': phone.text.trim(), 'address': address.text.trim(),
          'role': 'client', 'createdAt': FieldValue.serverTimestamp()
        });
        await FirebaseFirestore.instance.collection('clients').doc(cred.user!.uid).set({
          'uid': cred.user!.uid, 'email': email.text.trim(), 'name': fullName.text.trim(),
          'phone': phone.text.trim(), 'address': address.text.trim(), 'createdAt': FieldValue.serverTimestamp()
        });
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? 'Não foi possível autenticar.');
    } catch (_) { setState(() => error = 'Erro ao conectar. Confira a configuração do Firebase.'); }
    if (mounted) setState(() => busy = false);
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 82, height: 82, decoration: BoxDecoration(color: dark, borderRadius: BorderRadius.circular(24)),
          child: const Icon(Icons.remove_red_eye_outlined, color: lilac, size: 42)),
        const SizedBox(height: 18),
        const Text('Beauty Agenda', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
        const Text('Sua beleza, seus horários.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 28),
        if (register) ...[
          TextField(controller: fullName, decoration: const InputDecoration(labelText: 'Nome completo')),
          const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Telefone / WhatsApp')),
          const SizedBox(height: 12),
          TextField(controller: address, decoration: const InputDecoration(labelText: 'Endereço')),
          const SizedBox(height: 12),
        ],
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail')),
        const SizedBox(height: 12),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Senha (mínimo 6 caracteres)')),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: dark, padding: const EdgeInsets.all(15)),
          onPressed: busy ? null : submit, child: Text(busy ? 'Aguarde...' : register ? 'Criar conta da profissional' : 'Entrar'))),
        TextButton(onPressed: () => setState(() { register = !register; error = null; }),
          child: Text(register ? 'Já tenho conta — entrar' : 'Primeiro acesso? Criar conta')),
      ]),
    ))),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int index = 0;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Beauty Agenda'), actions: [
      IconButton(tooltip: 'Sair', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))
    ]),
    body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).snapshots(),
      builder: (context, roleSnap) {
        final role = roleSnap.data?.data()?['role'] ?? 'client';
        final isAdmin = role == 'admin';
        final pages = isAdmin
          ? const [AppointmentsPage(), InstantPage(), ClientsPage(), ServicesPage()]
          : const [ClientBookingPage(), InstantPage()];
        final safeIndex = index >= pages.length ? 0 : index;
        return Column(children: [Expanded(child: pages[safeIndex]), NavigationBar(
          selectedIndex: safeIndex, onDestinationSelected: (v) => setState(() => index = v),
          destinations: isAdmin ? const [
            NavigationDestination(icon: Icon(Icons.calendar_month), label: 'Agenda'),
            NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'Instant'),
            NavigationDestination(icon: Icon(Icons.people_alt_outlined), label: 'Clientes'),
            NavigationDestination(icon: Icon(Icons.spa_outlined), label: 'Serviços'),
          ] : const [
            NavigationDestination(icon: Icon(Icons.calendar_month), label: 'Agendar'),
            NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'Instant'),
          ],
        )]);
      },
    ),
    floatingActionButton: index == 0 ? StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).snapshots(),
      builder: (context, snap) => snap.data?.data()?['role'] == 'admin'
        ? FloatingActionButton.extended(backgroundColor: lilac, foregroundColor: dark, onPressed: () => showAppointmentForm(context), icon: const Icon(Icons.add), label: const Text('Agendar')) : const SizedBox.shrink()
    ) : null,

  );
}

class ClientBookingPage extends StatelessWidget {
  const ClientBookingPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Agende seu horário', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('Escolha o serviço e solicite seu atendimento. A confirmação depende da profissional.'),
    const SizedBox(height: 14),
    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('services').orderBy('name').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Text('Não foi possível carregar os serviços.');
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) return const Text('Ainda não há serviços cadastrados.');
        return Column(children: snap.data!.docs.map((doc) {
          final d = doc.data();
          return Card(child: ListTile(
            leading: const CircleAvatar(backgroundColor: lilac, child: Icon(Icons.spa, color: dark)),
            title: Text(d['name'] ?? ''), subtitle: Text('${d['duration'] ?? 60} minutos'),
            trailing: Text('R\$ ${((d['price'] ?? 0) as num).toStringAsFixed(2).replaceAll('.', ',')}'),
            onTap: () => _requestBooking(context, doc.id, d),
          ));
        }).toList());
      },
    ),
    const SizedBox(height: 24),
    const Text('Meus pedidos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('appointments')
        .where('clientId', isEqualTo: FirebaseAuth.instance.currentUser!.uid).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Text('Não foi possível carregar seus pedidos.');
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = [...snap.data!.docs]..sort((a, b) =>
          (b.data()['dateTime'] as Timestamp).compareTo(a.data()['dateTime'] as Timestamp));
        if (docs.isEmpty) return const Text('Você ainda não solicitou nenhum horário.');
        return Column(children: docs.map((doc) {
          final d = doc.data();
          final dateTime = (d['dateTime'] as Timestamp).toDate();
          final status = (d['status'] ?? 'Solicitado').toString();
          return Card(child: ListTile(
            title: Text(d['serviceName'] ?? 'Atendimento'),
            subtitle: Text('${DateFormat('dd/MM/yyyy • HH:mm').format(dateTime)}\n$status'),
            isThreeLine: true,
            trailing: status == 'Solicitado' ? TextButton(onPressed: () async {
              await FirebaseFirestore.instance.collection('appointments').doc(doc.id).update({'status': 'Cancelado'});
            }, child: const Text('Cancelar')) : null,
          ));
        }).toList());
      },
    ),
  ]);
}

Future<void> _requestBooking(BuildContext context, String serviceId, Map<String, dynamic> service) async {
  DateTime requested = DateTime.now().add(const Duration(days: 1));
  final note = TextEditingController();
  final result = await showDialog<DateTime>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => AlertDialog(
    title: Text('Solicitar: ${service['name']}'),
    content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Valor: R\$ ${((service['price'] ?? 0) as num).toStringAsFixed(2)}'),
      const SizedBox(height: 12),
      OutlinedButton.icon(icon: const Icon(Icons.calendar_month), label: Text(DateFormat('dd/MM/yyyy').format(requested)), onPressed: () async {
        final d = await showDatePicker(context: ctx, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)), initialDate: requested);
        if (d != null) setS(() => requested = DateTime(d.year, d.month, d.day, requested.hour, requested.minute));
      }),
      OutlinedButton.icon(icon: const Icon(Icons.access_time), label: Text(DateFormat('HH:mm').format(requested)), onPressed: () async {
        final t = await showTimePicker(context: ctx, initialTime: TimeOfDay.fromDateTime(requested));
        if (t != null) setS(() => requested = DateTime(requested.year, requested.month, requested.day, t.hour, t.minute));
      }),
      TextField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'Observações (opcional)')),
      const SizedBox(height: 6), const Text('O pedido será enviado para análise da profissional.'),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, requested), child: const Text('Solicitar horário'))],
  )));
  if (result == null) return;
  try {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final user = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    final data = user.data() ?? {};
    await FirebaseFirestore.instance.collection('appointments').add({
      'clientId': uid, 'clientName': data['name'] ?? data['email'] ?? 'Cliente',
      'email': data['email'] ?? '', 'phone': data['phone'] ?? '', 'address': data['address'] ?? '',
      'serviceId': serviceId, 'serviceName': service['name'] ?? '', 'price': service['price'] ?? 0,
      'dateTime': Timestamp.fromDate(result), 'status': 'Solicitado', 'notes': note.text.trim(),
      'createdBy': uid, 'createdAt': FieldValue.serverTimestamp(),
    });
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Solicitação enviada à profissional.')));
  } catch (_) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível solicitar o horário. Verifique o Firebase.')));
  }
}

class AppointmentsPage extends StatelessWidget {
  const AppointmentsPage({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('appointments').orderBy('dateTime').snapshots(),
    builder: (context, snap) {
      if (snap.hasError) return const Center(child: Text('Erro ao carregar agenda. Verifique as regras do Firebase.'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snap.data!.docs;
      if (docs.isEmpty) return const Center(child: Text('Nenhum horário agendado. Toque em “Agendar”.'));
      return ListView.builder(padding: const EdgeInsets.all(14), itemCount: docs.length, itemBuilder: (context, i) {
        final d = docs[i].data();
        final dt = (d['dateTime'] as Timestamp).toDate();
        return Card(child: ListTile(
          leading: CircleAvatar(backgroundColor: lilac.withValues(alpha: .3), child: const Icon(Icons.remove_red_eye_outlined, color: dark)),
          title: Text(d['clientName'] ?? 'Cliente', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${DateFormat('dd/MM/yyyy • HH:mm').format(dt)}\n${d['serviceName'] ?? ''} • ${d['status'] ?? 'Agendado'}'),
          isThreeLine: true,
          trailing: Text('R\$ ${((d['price'] ?? 0) as num).toStringAsFixed(2).replaceAll('.', ',')}'),
          onTap: () => showAppointmentDetails(context, docs[i].id, d),
        ));
      });
    },
  );
}

Future<void> showAppointmentForm(BuildContext context) async {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController(), phone = TextEditingController(), email = TextEditingController();
  final address = TextEditingController();
  DateTime dateTime = DateTime.now().add(const Duration(hours: 1));
  String? serviceId, serviceName;
  double price = 0;
  await showModalBottomSheet(context: context, isScrollControlled: true, builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
    return Padding(padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
      child: SingleChildScrollView(child: Form(key: formKey, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Novo agendamento', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Nome da cliente *'), validator: (v) => v == null || v.trim().isEmpty ? 'Informe o nome' : null),
        const SizedBox(height: 10),
        TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Telefone / WhatsApp')),
        const SizedBox(height: 10),
        TextFormField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail')),
        const SizedBox(height: 10),
        TextFormField(controller: address, decoration: const InputDecoration(labelText: 'Endereço (opcional)')),
        const SizedBox(height: 10),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('services').orderBy('name').snapshots(),
          builder: (context, snap) {
            final items = snap.data?.docs ?? [];
            return DropdownButtonFormField<String>(
              value: serviceId, decoration: const InputDecoration(labelText: 'Serviço *'),
              items: items.map((d) => DropdownMenuItem(value: d.id, child: Text('${d.data()['name']} — R\$ ${((d.data()['price'] ?? 0) as num).toStringAsFixed(2)}'))).toList(),
              onChanged: (v) { final matches = items.where((d) => d.id == v); final doc = matches.isEmpty ? null : matches.first; setS(() { serviceId = v; serviceName = doc?.data()['name']; price = ((doc?.data()['price'] ?? 0) as num).toDouble(); }); },
              validator: (v) => v == null ? 'Cadastre/seleciona um serviço' : null,
            );
          },
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () async {
          final d = await showDatePicker(context: ctx, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)), initialDate: dateTime);
          if (d == null || !ctx.mounted) return;
          final t = await showTimePicker(context: ctx, initialTime: TimeOfDay.fromDateTime(dateTime));
          if (t != null) setS(() => dateTime = DateTime(d.year, d.month, d.day, t.hour, t.minute));
        }, icon: const Icon(Icons.access_time), label: Text(DateFormat('dd/MM/yyyy • HH:mm').format(dateTime))),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: () async {
            if (!formKey.currentState!.validate()) return;
            try {
              final client = await FirebaseFirestore.instance.collection('clients').add({
                'name': name.text.trim(), 'phone': phone.text.trim(), 'email': email.text.trim(),
                'address': address.text.trim(), 'createdAt': FieldValue.serverTimestamp(),
              });
              await FirebaseFirestore.instance.collection('appointments').add({
                'clientId': client.id, 'clientName': name.text.trim(), 'phone': phone.text.trim(),
                'email': email.text.trim(), 'address': address.text.trim(), 'serviceId': serviceId,
                'serviceName': serviceName, 'price': price, 'dateTime': Timestamp.fromDate(dateTime),
                'status': 'Agendado', 'createdBy': FirebaseAuth.instance.currentUser?.uid,
                'createdAt': FieldValue.serverTimestamp(),
              });
              if (ctx.mounted) Navigator.pop(ctx);
              await _notify('Agendamento salvo', '${name.text.trim()} • ${DateFormat('dd/MM HH:mm').format(dateTime)}');
              if (phone.text.trim().isNotEmpty) {
                final msg = 'Olá ${name.text.trim()}! Seu horário de ${serviceName ?? 'atendimento'} está agendado para ${DateFormat('dd/MM/yyyy às HH:mm').format(dateTime)}. Beauty Agenda.';
                final uri = Uri.parse('https://wa.me/${phone.text.replaceAll(RegExp(r'[^0-9]'), '')}?text=${Uri.encodeComponent(msg)}');
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: const Text('Agendamento salvo. Abra o WhatsApp para enviar a confirmação.'), action: SnackBarAction(label: 'WhatsApp', onPressed: () => launchUrl(uri, mode: LaunchMode.externalApplication))));
              }
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível salvar. Confira sua conexão e o Firebase.')));
            }
          }, child: const Text('Salvar agendamento'))),
      ]))),
    );
  }));
}

Future<void> _notify(String title, String body) async {
  await notifications.show(DateTime.now().millisecondsSinceEpoch ~/ 1000,
    title, body, const NotificationDetails(android: AndroidNotificationDetails(
      'beauty_agenda', 'Beauty Agenda', channelDescription: 'Avisos de agendamento', importance: Importance.high, priority: Priority.high)));
}

void showAppointmentDetails(BuildContext context, String id, Map<String, dynamic> d) {
  showModalBottomSheet(context: context, builder: (ctx) {
    final dt = (d['dateTime'] as Timestamp).toDate();
    return Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(d['clientName'] ?? 'Cliente', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      Text('${d['serviceName'] ?? ''} • ${DateFormat('dd/MM/yyyy HH:mm').format(dt)}'),
      Text('Telefone: ${d['phone'] ?? '-'}'), Text('E-mail: ${d['email'] ?? '-'}'),
      const SizedBox(height: 12),
      Wrap(spacing: 8, children: [
        for (final status in ['Confirmado', 'Concluído', 'Cancelado'])
          OutlinedButton(onPressed: () async {
            await FirebaseFirestore.instance.collection('appointments').doc(id).update({'status': status});
            if (ctx.mounted) Navigator.pop(ctx);
          }, child: Text(status)),
      ]),
      if ((d['phone'] ?? '').toString().isNotEmpty)
        TextButton.icon(onPressed: () {
          final digits = d['phone'].toString().replaceAll(RegExp(r'[^0-9]'), '');
          launchUrl(Uri.parse('https://wa.me/$digits?text=${Uri.encodeComponent('Olá ${d['clientName']}, confirmando seu horário de ${DateFormat('dd/MM/yyyy às HH:mm').format(dt)}.') }'), mode: LaunchMode.externalApplication);
        }, icon: const Icon(Icons.chat), label: const Text('Enviar WhatsApp')),
      TextButton.icon(onPressed: () async {
        await FirebaseFirestore.instance.collection('appointments').doc(id).delete();
        if (ctx.mounted) Navigator.pop(ctx);
      }, icon: const Icon(Icons.delete_outline), label: const Text('Excluir agendamento')),
    ]));
  });
}


class InstantPage extends StatelessWidget {
  const InstantPage({super.key});

  Future<bool> _isAdmin() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;
    final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    return doc.data()?['role'] == 'admin';
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
    future: _isAdmin(),
    builder: (context, roleSnap) {
      final isAdmin = roleSnap.data == true;
      return Column(children: [
        Container(width: double.infinity, padding: const EdgeInsets.fromLTRB(16, 18, 16, 14), color: dark,
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('BEAUTY INSTANT', style: TextStyle(color: lilac, fontSize: 12, letterSpacing: 2, fontWeight: FontWeight.bold)),
            SizedBox(height: 4), Text('Momentos de beleza', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            Text('Fotos, vídeos curtos e novidades do estúdio', style: TextStyle(color: Colors.white70)),
          ])),
        if (isAdmin) Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity,
          child: FilledButton.icon(onPressed: () => _createPost(context), icon: const Icon(Icons.add_a_photo_outlined), label: const Text('Publicar momento')))),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('instant_posts').orderBy('createdAt', descending: true).snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Não foi possível carregar o Instant. Confira o Firebase.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs;
            if (docs.isEmpty) return const Center(child: Text('Ainda não há momentos publicados.'));
            return ListView.builder(padding: const EdgeInsets.all(12), itemCount: docs.length, itemBuilder: (context, i) {
              final doc = docs[i]; final d = doc.data();
              return Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (d['mediaType'] == 'video') VideoPost(url: d['mediaUrl'] ?? '')
                else Image.network(d['mediaUrl'] ?? '', width: double.infinity, fit: BoxFit.cover,
                  loadingBuilder: (c, child, progress) => progress == null ? child : const SizedBox(height: 220, child: Center(child: CircularProgressIndicator())),
                  errorBuilder: (_, __, ___) => const SizedBox(height: 180, child: Center(child: Icon(Icons.broken_image_outlined, size: 48)))),
                Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(d['caption'] ?? '', style: const TextStyle(fontSize: 15)),
                  const SizedBox(height: 6),
                  Row(children: [const Icon(Icons.auto_awesome, color: lilac, size: 18), const SizedBox(width: 6),
                    Text(d['mediaType'] == 'video' ? 'Vídeo curto' : 'Foto / momento', style: const TextStyle(color: Colors.black54)),
                    const Spacer(), if (isAdmin) IconButton(tooltip: 'Excluir publicação', icon: const Icon(Icons.delete_outline), onPressed: () async {
                      await FirebaseFirestore.instance.collection('instant_posts').doc(doc.id).delete();
                      final path = d['storagePath'];
                      if (path != null) { try { await FirebaseStorage.instance.ref(path).delete(); } catch (_) {} }
                    })]),
                ])),
              ]));
            });
          },
        )),
      ]);
    },
  );

  Future<void> _createPost(BuildContext context) async {
    final caption = TextEditingController();
    XFile? picked;
    String type = 'image';
    bool busy = false;
    await showModalBottomSheet(context: context, isScrollControlled: true, builder: (sheetContext) => StatefulBuilder(builder: (ctx, setS) =>
      Padding(padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20), child: SingleChildScrollView(child: Column(
        mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Publicar no Instant', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Wrap(spacing: 8, children: [
            ChoiceChip(label: const Text('Foto'), selected: type == 'image', onSelected: (_) => setS(() => type = 'image')),
            ChoiceChip(label: const Text('Vídeo curto'), selected: type == 'video', onSelected: (_) => setS(() => type = 'video')),
          ]),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: busy ? null : () async {
            final picker = ImagePicker();
            final result = type == 'image' ? await picker.pickImage(source: ImageSource.gallery, imageQuality: 85)
              : await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 90));
            if (result != null) setS(() => picked = result);
          }, icon: Icon(type == 'image' ? Icons.photo_library_outlined : Icons.video_library_outlined),
            label: Text(picked == null ? 'Escolher ${type == 'image' ? 'foto' : 'vídeo'} da galeria' : 'Arquivo selecionado: ${picked!.name}')),
          TextField(controller: caption, maxLines: 3, decoration: const InputDecoration(labelText: 'Legenda do momento', hintText: 'Novidade, bastidores, resultado...')),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: busy || picked == null ? null : () async {
            setS(() => busy = true);
            try {
              final uid = FirebaseAuth.instance.currentUser!.uid;
              final path = 'instant/$uid/${DateTime.now().millisecondsSinceEpoch}_${picked!.name.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_')}';
              final ref = FirebaseStorage.instance.ref(path);
              final task = await ref.putFile(File(picked!.path));
              final url = await task.ref.getDownloadURL();
              await FirebaseFirestore.instance.collection('instant_posts').add({
                'mediaUrl': url, 'storagePath': path, 'mediaType': type, 'caption': caption.text.trim(),
                'createdBy': uid, 'createdAt': FieldValue.serverTimestamp(),
              });
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Momento publicado!')));
            } catch (e) {
              setS(() => busy = false);
              if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Falha ao publicar. Confira Firebase Storage e permissões.')));
            }
          }, child: Text(busy ? 'Enviando mídia...' : 'Publicar momento'))),
        ],
      ))));
  }
}

class VideoPost extends StatefulWidget {
  final String url;
  const VideoPost({super.key, required this.url});
  @override State<VideoPost> createState() => _VideoPostState();
}
class _VideoPostState extends State<VideoPost> {
  VideoPlayerController? controller;
  @override void initState() {
    super.initState();
    controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))..initialize().then((_) { if (mounted) setState(() {}); });
  }
  @override void dispose() { controller?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final c = controller;
    if (c == null || !c.value.isInitialized) return const SizedBox(height: 220, child: Center(child: CircularProgressIndicator()));
    return AspectRatio(aspectRatio: c.value.aspectRatio, child: Stack(alignment: Alignment.center, children: [
      VideoPlayer(c), IconButton.filledTonal(onPressed: () { setState(() { c.value.isPlaying ? c.pause() : c.play(); }); },
        iconSize: 42, icon: Icon(c.value.isPlaying ? Icons.pause_circle : Icons.play_circle)),
      Positioned(bottom: 0, left: 0, right: 0, child: VideoProgressIndicator(c, allowScrubbing: true, colors: const VideoProgressColors(playedColor: lilac))),
    ]));
  }
}

class ClientsPage extends StatelessWidget {
  const ClientsPage({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('clients').orderBy('name').snapshots(),
    builder: (context, snap) {
      if (snap.hasError) return const Center(child: Text('Erro ao carregar clientes.'));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snap.data!.docs;
      if (docs.isEmpty) return const Center(child: Text('Os clientes aparecerão aqui após o primeiro cadastro.'));
      return ListView(padding: const EdgeInsets.all(12), children: docs.map((doc) {
        final d = doc.data();
        return Card(child: ListTile(leading: const CircleAvatar(backgroundColor: lilac, child: Icon(Icons.person, color: dark)),
          title: Text(d['name'] ?? ''), subtitle: Text('${d['phone'] ?? ''}\n${d['email'] ?? ''}'), isThreeLine: true));
      }).toList());
    },
  );
}

class ServicesPage extends StatelessWidget {
  const ServicesPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.transparent,
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('services').orderBy('name').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('Erro ao carregar serviços.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        return ListView(padding: const EdgeInsets.all(14), children: [
          const Text('Seus serviços', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const Text('Cadastre seus procedimentos e valores.'),
          const SizedBox(height: 10),
          ...docs.map((doc) => Card(child: ListTile(title: Text(doc.data()['name'] ?? ''), subtitle: Text('${doc.data()['duration'] ?? 60} minutos'),
            trailing: Text('R\$ ${((doc.data()['price'] ?? 0) as num).toStringAsFixed(2).replaceAll('.', ',')}',
              style: const TextStyle(fontWeight: FontWeight.bold)),
            onLongPress: () => FirebaseFirestore.instance.collection('services').doc(doc.id).delete()))),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => _addService(context), icon: const Icon(Icons.add), label: const Text('Adicionar serviço')),
          const SizedBox(height: 8),
          const Text('Dica: mantenha pressionado um serviço para excluí-lo.', style: TextStyle(color: Colors.black54)),
        ]);
      },
    ),
  );
}

Future<void> _addService(BuildContext context) async {
  final name = TextEditingController(), price = TextEditingController(), duration = TextEditingController(text: '60');
  await showDialog(context: context, builder: (ctx) => AlertDialog(
    title: const Text('Novo serviço'),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome do serviço')),
      const SizedBox(height: 8),
      TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Preço (ex.: 85,00)')),
      const SizedBox(height: 8),
      TextField(controller: duration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Duração em minutos')),
    ])),
    actions: [
      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
      FilledButton(onPressed: () async {
        final p = double.tryParse(price.text.trim().replaceAll(',', '.'));
        if (name.text.trim().isEmpty || p == null || p < 0) return;
        await FirebaseFirestore.instance.collection('services').add({
          'name': name.text.trim(), 'price': p, 'duration': int.tryParse(duration.text) ?? 60,
          'createdAt': FieldValue.serverTimestamp(),
        });
        if (ctx.mounted) Navigator.pop(ctx);
      }, child: const Text('Salvar')),
    ],
  ));
}
