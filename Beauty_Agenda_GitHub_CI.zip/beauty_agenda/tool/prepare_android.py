"""Patch Flutter-generated Android scaffold for Beauty Agenda."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
app_gradle_files = list((root / "android" / "app").glob("build.gradle")) + list((root / "android" / "app").glob("build.gradle.kts"))
if not app_gradle_files:
    raise SystemExit("Flutter did not generate android/app/build.gradle(.kts)")
for path in app_gradle_files:
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".kts":
        text = re.sub(r'applicationId\s*=\s*"[^"]+"', 'applicationId = "com.beautyagenda.app"', text, count=1)
        if "isCoreLibraryDesugaringEnabled" not in text:
            text = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true\n', text, count=1)
        if "desugar_jdk_libs" not in text:
            text = re.sub(r'dependencies\s*\{', 'dependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n', text, count=1)
    else:
        text = re.sub(r'applicationId\s+"[^"]+"', 'applicationId "com.beautyagenda.app"', text, count=1)
        if "coreLibraryDesugaringEnabled" not in text:
            text = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true\n', text, count=1)
        if "desugar_jdk_libs" not in text:
            text = re.sub(r'dependencies\s*\{', "dependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n", text, count=1)
    path.write_text(text, encoding="utf-8")

manifest = root / "android/app/src/main/AndroidManifest.xml"
text = manifest.read_text(encoding="utf-8")
if "POST_NOTIFICATIONS" not in text:
    text = text.replace('<application', '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application', 1)
text = re.sub(r'android:label="[^"]*"', 'android:label="Beauty Agenda"', text, count=1)
manifest.write_text(text, encoding="utf-8")
print("Android scaffold patched; applicationId=com.beautyagenda.app")
