"""Generate Android FirebaseOptions from Firebase Console's google-services.json."""
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parents[1]
raw = os.environ.get("GOOGLE_SERVICES_JSON", "").strip()
if not raw:
    raise SystemExit("Missing GitHub Actions secret GOOGLE_SERVICES_JSON")
try:
    config = json.loads(raw)
except json.JSONDecodeError as exc:
    raise SystemExit(f"GOOGLE_SERVICES_JSON is not valid JSON: {exc}")
project = config.get("project_info", {})
expected_package = "com.beautyagenda.app"
client = next((c for c in config.get("client", [])
               if c.get("client_info", {}).get("android_client_info", {}).get("package_name") == expected_package), None)
if client is None:
    raise SystemExit(f"google-services.json has no Android client for {expected_package}. Register that exact package in Firebase.")
client_info = client.get("client_info", {})
api_keys = client.get("api_key", [])
api_key = next((k.get("current_key") for k in api_keys if k.get("current_key")), None)
app_id = client_info.get("mobilesdk_app_id")
project_id = project.get("project_id")
sender_id = project.get("project_number")
if not all([api_key, app_id, project_id, sender_id]):
    raise SystemExit("Firebase config is missing apiKey, appId, project_id, or project_number.")
fields = {
    "apiKey": api_key,
    "appId": app_id,
    "messagingSenderId": sender_id,
    "projectId": project_id,
}
if project.get("storage_bucket"):
    fields["storageBucket"] = project["storage_bucket"]
lines = ["import 'package:firebase_core/firebase_core.dart';", "", "/// Generated in GitHub Actions from the Firebase Console Android config.", "class DefaultFirebaseOptions {", "  static FirebaseOptions get currentPlatform => android;", "", "  static const FirebaseOptions android = FirebaseOptions("]
for key, value in fields.items():
    lines.append(f"    {key}: {json.dumps(str(value))},")
lines += ["  );", "}", ""]
(root / "lib/firebase_options.dart").write_text("\n".join(lines), encoding="utf-8")
print("Firebase options generated for Android applicationId=com.beautyagenda.app")
